

var count = 0;
var checkoutDetail = [];

var booksUrl =[ "https://images-na.ssl-images-amazon.com/images/I/41dKQFiOXKL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/916epYlsgUL._AC_SY230_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/A1K%2B9dqyWdL._AC_SY230_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/91wr7Rq7ZaL._AC_SY230_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/618QuJqPYmL._SX329_BO1,204,203,200_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/51EobVielcL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/51ehrDSNWaL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/A1wyfObutwL._AC_SY230_.jpg"
              ] ;

var lapUrl  =  ["https://images-na.ssl-images-amazon.com/images/I/412ha3l7XiL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/61wsBhUZqyL._SL1200_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/418g6Q3eTHL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/5181osZq%2BFL._SL1000_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/41sSa7s0mIL._AC_US218_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/81Yd-xXWdcL._SX569_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/61cvx3cPAEL._SL1000_.jpg"
              , "https://images-na.ssl-images-amazon.com/images/I/41ep9XKCNHL._AC_US218_.jpg"
              ];

var oUrl = [ "https://images-eu.ssl-images-amazon.com/images/I/61eOlq-nR3L._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/51svBJUx6JL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/41feLIUHFmL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/51MkMSst6JL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/51z5yR80ROL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/51rMpOYHufL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/6156in5PV9L._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           , "https://images-eu.ssl-images-amazon.com/images/I/412eexNKJuL._AC_UL260_SR200,260_FMwebp_QL70_.jpg"
           ]


var laptopJson = [{url :lapUrl[0] ,name :"Dell Inspiron 7000 2-in-1",money :"$735"},
                 {url :lapUrl[1] ,name : "Microsoft Surface Laptop ",money :"$1,090"},
                 {url :lapUrl[2] ,name : "Microsoft Surface Pro",money :"$699"},
                 {url :lapUrl[3] ,name : " Google Pixelbook (i5, 8 GB RAM, 128GB)",money :"$809"},
                 {url :lapUrl[4] ,name : "HP envy",money :"$800"},
                 {url :lapUrl[5] ,name : "Dell XPS Thin & Light Gaming Laptop - 15.6",money :"$1,740"},
                 {url :lapUrl[6] ,name : "Dell Inspiron 7000 15.6 Convertible 2-in-1 FHD ",money :"$920"},
                 {url :lapUrl[7] ,name : "Asus vivo book",money :"$620"}
                 ];

 var booksJson = [{url :booksUrl[0] ,name : "A place for us : novel",money :"$12"},
                 {url :booksUrl[1] ,name : "the Ragged Edge of night",money :"$8"},
                 {url :booksUrl[2] ,name : "What have you done",money :"$20"},
                 {url :booksUrl[3] ,name : "the woman in the window.A.J Finn",money :"$18"},
                 {url :booksUrl[4] ,name : "The feather theif",money :"$22"},
                 {url :booksUrl[5] ,name : "Look Alive out there",money :"$15"},
                 {url :booksUrl[6] ,name : "I am maggie I am ..",money :"$17"},
                 {url :booksUrl[7] ,name : " Zelda",money :"$8"}
                 ];

 var oJson = [{url :oUrl[0] ,name : "Sukkhi Jewellery Set for Women",money :"$12"},
                 {url :oUrl[1] ,name : "Sukkhi Jewellery Sets for Women (413CB1900)",money :"$28"},
                 {url :oUrl[2] ,name : "Sukkhi Jewellery Sets for Women ",money :"$21"},
                 {url :oUrl[3] ,name : "Sukkhi Jewellery Sets for Women (N71928GLDPH092017)",money :"$5"},
                 {url :oUrl[4] ,name : "Sukkhi Jewellery Sets for Women (457CB2700)",money :"$23"},
                 {url :oUrl[5] ,name : "Sukkhi Choker Necklace for Women (N71437GLDPAP3050)",money :"$9"},
                 {url :oUrl[6] ,name : "Sukkhi Jewellery Set for Women (N71789GLDPM1250 ",money :"$17"},
                 {url :oUrl[7] ,name : "Sukkhi Jewellery Set for Women (263CB1960)",money :"$30"}
                 ]

var params = (new URL(document.location)).searchParams
console.log(params);
var productId = params.get("product");
var dummyJson;
    switch(productId){

        case "books" : 
                        dummyJson = booksJson;
                        break;
        case "laptop" : 
                        dummyJson = laptopJson;
                        break;
        case "ornaments" :
                        dummyJson = oJson;
                        break;
        default :
                        alert("the product currently not available");
                        window.location = "index.html";

    }
    
// var dummyJson = productId == "books" ? booksJson : laptopJson;


function checkout(){
    console.log("checkout");
    console.log(document.getElementById("content"));
    window.location = "cart.html";
}
  


function imageClick(tree){
        console.log("here",tree.target.attributes[0].value) ;
        
}

function addtocart(name,url,amount){
    console.log(name,url,amount);
    document.getElementById(name).style.backgroundColor = "red";
    checkoutDetail[count] =  [{pname :name, purl : url,pamount:amount}];
    count ++;
    console.log(checkoutDetail);
    localStorage.setItem("data",JSON.stringify(checkoutDetail));
}

