
var checkoutData = JSON.parse(localStorage.getItem("data"));
    console.log(checkoutData);
 

    function confirm(){
        window.location = "tView.html";
    }



    



        
