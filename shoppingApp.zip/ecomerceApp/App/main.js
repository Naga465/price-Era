

var count = 0;
var checkoutDetail = [];
var path = "dist/"

var booksUrl =  [ path +"b1.jpg"
                , path +"b2.jpg"
                , path +"b3.jpg"
                , path +"b4.jpg" 
                , path +"b5.jpg" 
                , path +"b6.jpg"
                , path +"b7.jpg"
                , path +"b8.jpg"
                ] ;

var lapUrl  =   [ path +"l1.jpg"
                , path +"l2.jpg"
                , path +"l3.jpg"
                , path +"l4.jpg" 
                , path +"l5.jpg" 
                , path +"l6.jpg"
                , path +"l7.jpg"
                , path +"l8.jpg"
                ] ; 

var oUrl =      [ path +"o1.jpg"
                , path +"o2.jpg"
                , path +"o3.jpg"
                , path +"o4.jpg" 
                , path +"o5.jpg" 
                , path +"o6.jpg"
                , path +"o7.jpg"
                , path +"o8.jpg"
                ] ;


var laptopJson = [{url :lapUrl[0] ,name :"Dell Inspiron 7000 2-in-1",money :"$735"},
                 {url :lapUrl[1] ,name : "Microsoft Surface Laptop ",money :"$1,090"},
                 {url :lapUrl[2] ,name : "Microsoft Surface Pro",money :"$699"},
                 {url :lapUrl[3] ,name : " Google Pixelbook (i5, 8 GB RAM, 128GB)",money :"$809"},
                 {url :lapUrl[4] ,name : "HP envy",money :"$800"},
                 {url :lapUrl[5] ,name : "Dell XPS Thin & Light Gaming Laptop - 15.6",money :"$1,740"},
                 {url :lapUrl[6] ,name : "Dell Inspiron 7000 15.6 Convertible 2-in-1 FHD ",money :"$920"},
                 {url :lapUrl[7] ,name : "Asus vivo book",money :"$620"}
                 ];

 var booksJson = [{url :booksUrl[0] ,name : "A place for us : novel",money :"$12"},
                 {url :booksUrl[1] ,name : "the Ragged Edge of night",money :"$8"},
                 {url :booksUrl[2] ,name : "What have you done",money :"$20"},
                 {url :booksUrl[3] ,name : "the woman in the window.A.J Finn",money :"$18"},
                 {url :booksUrl[4] ,name : "The feather theif",money :"$22"},
                 {url :booksUrl[5] ,name : "Look Alive out there",money :"$15"},
                 {url :booksUrl[6] ,name : "I am maggie I am ..",money :"$17"},
                 {url :booksUrl[7] ,name : " Zelda",money :"$8"}
                 ];

 var oJson = [{url :oUrl[0] ,name : "Sukkhi Jewellery Set for Women",money :"$12"},
                 {url :oUrl[1] ,name : "Sukkhi Jewellery Sets for Women (413CB1900)",money :"$28"},
                 {url :oUrl[2] ,name : "Sukkhi Jewellery Sets for Women ",money :"$21"},
                 {url :oUrl[3] ,name : "Sukkhi Jewellery Sets for Women (N71928GLDPH092017)",money :"$5"},
                 {url :oUrl[4] ,name : "Sukkhi Jewellery Sets for Women (457CB2700)",money :"$23"},
                 {url :oUrl[5] ,name : "Sukkhi Choker Necklace for Women (N71437GLDPAP3050)",money :"$9"},
                 {url :oUrl[6] ,name : "Sukkhi Jewellery Set for Women (N71789GLDPM1250 ",money :"$17"},
                 {url :oUrl[7] ,name : "Sukkhi Jewellery Set for Women (263CB1960)",money :"$30"}
                 ]

var params = (new URL(document.location)).searchParams
console.log(params);
var productId = params.get("product");
var dummyJson;
    switch(productId){

        case "books" : 
                        dummyJson = booksJson;
                        break;
        case "laptops" : 
                        dummyJson = laptopJson;
                        break;
        case "ornaments" :
                        dummyJson = oJson;
                        break;
        default :
                        alert("the product currently not available");
                        window.location = "index.html";

    }
    
// var dummyJson = productId == "books" ? booksJson : laptopJson;


function checkout(){
    console.log("checkout");
    console.log(document.getElementById("content"));
    window.location = "cart.html";
}
  


function imageClick(tree){
        console.log("here",tree.target.attributes[0].value) ;
        
}

function addtocart(name,url,amount){
    console.log(name,url,amount);
    document.getElementById(name).style.backgroundColor = "red";
    checkoutDetail[count] =  [{pname :name, purl : url,pamount:amount}];
    count ++;
    console.log(checkoutDetail);
    localStorage.setItem("data",JSON.stringify(checkoutDetail));
}

function back (){
    window.location= "index.html";
}

